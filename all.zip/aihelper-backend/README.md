# AI 助手后端（aihelper-backend）

[![GitHub stars](https://img.shields.io/github/stars/zhaoxi7109/aihelper?style=social)](https://github.com/zhaoxi7109/aihelper/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/zhaoxi7109/aihelper?style=social)](https://github.com/zhaoxi7109/aihelper/network/members)
[![GitHub issues](https://img.shields.io/github/issues/zhaoxi7109/aihelper)](https://github.com/zhaoxi7109/aihelper/issues)
[![GitHub license](https://img.shields.io/github/license/zhaoxi7109/aihelper)](https://github.com/zhaoxi7109/aihelper/blob/main/LICENSE)

项目地址：https://github.com/zhaoxi7109/aihelper.git

本项目是基于 Spring Boot 3、MyBatis、Spring Security、JWT、Redis、阿里云 OSS、Spring AI Alibaba 等技术栈开发的 AI 助手后端服务，支持多用户、多会话、消息图片上传与 OCR 识别、AI 对话等功能。

## 项目截图

### 登录界面

![登录界面](./login.png)

### 数据统计

![数据统计](./chart.png)

## 主要功能

- 用户注册、登录、JWT 鉴权
- 多会话管理与消息记录
- 支持消息图片上传、OCR 识别与图片内容管理
- AI 对话与推理内容存储
- 支持通过 Spring AI Alibaba 集成百炼大模型
- 支持图像识别和多模态交互
- Swagger3 在线 API 文档
- 支持阿里云 OSS、Redis 缓存

## 技术栈

- Spring Boot 3.4.x
- MyBatis
- Spring Security & JWT
- Redis
- MySQL
- Spring AI Alibaba 1.0.0.2
- 阿里云 OSS、OCR
- 百炼大模型（DashScope）
- Swagger3 (springdoc-openapi)

## 快速启动

### 1. 克隆项目

```bash
git clone https://github.com/zhaoxi7109/aihelper.git
cd aihelper-backend
```

### 2. 数据库初始化

1. 创建 MySQL 数据库 `aihelper`，字符集 `utf8mb4`。
2. 执行 `src/main/resources/db/database.sql` 脚本，完成表结构和初始数据导入。

### 3. 配置修改

- 修改 `src/main/resources/application.yml`，根据实际环境调整数据库、Redis、OSS、Spring AI Alibaba 等配置。

### 4. 启动项目

```bash
# 使用Maven
./mvnw spring-boot:run
# 或
mvn spring-boot:run
```

项目默认端口：`8080`

### 5. 访问 API 文档

- Swagger UI: [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

## 数据库结构

详细设计见 [`src/main/resources/db/database.md`](src/main/resources/db/database.md)。

## 主要配置说明（application.yml）

- 数据库：`spring.datasource.*`
- Redis：`spring.data.redis.*`
- OSS：`aliyun.oss.*`
- Spring AI Alibaba：
  - 百炼大模型：`spring.ai.alibaba.dashscope.api-key`
  - 模型配置：`spring.ai.alibaba.dashscope.*`
- JWT 密钥：`jwt.secret`

## Spring AI Alibaba 集成

本项目使用 Spring AI Alibaba 框架集成了阿里云百炼大模型，主要特性：

- 自动配置的 ChatClient 用于文本对话
- 自动配置的 ImageModel 用于图像处理
- 支持多模态交互（文本+图像输入）
- 可扩展的 AI 能力接口

配置示例：

```yaml
spring:
  ai:
    alibaba:
      dashscope:
        api-key: ${DASHSCOPE_API_KEY}
        chat:
          options:
            model: qwen-max
        image:
          options:
            model: wanx-v1
```

## 常见问题

- **数据库连接失败**：请确认 MySQL 已启动，配置正确，且已初始化表结构。
- **Redis 未连接**：请确认 Redis 服务已启动。
- **OSS/百炼 API 未配置**：请在 application.yml 中补充相关密钥。
- **Spring AI Alibaba 配置问题**：检查 application.yml 中的 spring.ai.alibaba 配置是否正确。

## 贡献与反馈

如有建议或问题，欢迎提 issue 或 PR。

---

> © 2024 Zhaoxi. 本项目仅供学习与交流使用。

---

# AI Assistant Backend (aihelper-backend)

[![GitHub stars](https://img.shields.io/github/stars/zhaoxi7109/aihelper?style=social)](https://github.com/zhaoxi7109/aihelper/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/zhaoxi7109/aihelper?style=social)](https://github.com/zhaoxi7109/aihelper/network/members)
[![GitHub issues](https://img.shields.io/github/issues/zhaoxi7109/aihelper)](https://github.com/zhaoxi7109/aihelper/issues)
[![GitHub license](https://img.shields.io/github/license/zhaoxi7109/aihelper)](https://github.com/zhaoxi7109/aihelper/blob/main/LICENSE)

Repository: https://github.com/zhaoxi7109/aihelper.git

This project is an AI assistant backend service based on Spring Boot 3, MyBatis, Spring Security, JWT, Redis, Alibaba Cloud OSS, and Spring AI Alibaba. It supports multi-user, multi-session, message image upload & OCR, and AI conversation features.

## Screenshots

### Login Interface

![Login Interface](./login.png)

### Data Statistics

![Data Statistics](./chart.png)

## Features

- User registration, login, JWT authentication
- Multi-session management and message history
- Message image upload, OCR recognition, and image management
- AI conversation and reasoning content storage
- Integration with DashScope LLM via Spring AI Alibaba
- Support for image recognition and multimodal interaction
- Swagger3 online API documentation
- Support for Alibaba Cloud OSS, Redis cache

## Tech Stack

- Spring Boot 3.4.x
- MyBatis
- Spring Security & JWT
- Redis
- MySQL
- Spring AI Alibaba 1.0.0.2
- Alibaba Cloud OSS, OCR
- DashScope LLM
- Swagger3 (springdoc-openapi)

## Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/zhaoxi7109/aihelper.git
cd aihelper-backend
```

### 2. Database initialization

1. Create a MySQL database named `aihelper` with charset `utf8mb4`.
2. Execute `src/main/resources/db/database.sql` to initialize tables and seed data.

### 3. Configuration

- Edit `src/main/resources/application.yml` to set up your database, Redis, OSS, Spring AI Alibaba, etc.

### 4. Start the project

```bash
# With Maven
./mvnw spring-boot:run
# or
mvn spring-boot:run
```

Default port: `8080`

### 5. API Documentation

- Swagger UI: [http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

## Database Structure

See [`src/main/resources/db/database.md`](src/main/resources/db/database.md) for details.

## Main Configurations (application.yml)

- Database: `spring.datasource.*`
- Redis: `spring.data.redis.*`
- OSS: `aliyun.oss.*`
- Spring AI Alibaba:
  - DashScope LLM: `spring.ai.alibaba.dashscope.api-key`
  - Model Configuration: `spring.ai.alibaba.dashscope.*`
- JWT secret: `jwt.secret`

## Spring AI Alibaba Integration

This project integrates Alibaba Cloud's DashScope LLM using Spring AI Alibaba framework with the following features:

- Auto-configured ChatClient for text conversations
- Auto-configured ImageModel for image processing
- Support for multimodal interaction (text + image input)
- Extensible AI capability interfaces

Configuration example:

```yaml
spring:
  ai:
    alibaba:
      dashscope:
        api-key: ${DASHSCOPE_API_KEY}
        chat:
          options:
            model: qwen-max
        image:
          options:
            model: wanx-v1
```

## FAQ

- **Database connection failed**: Make sure MySQL is running, config is correct, and tables are initialized.
- **Redis not connected**: Make sure Redis is running.
- **OSS/DashScope API not configured**: Fill in the required keys in application.yml.
- **Spring AI Alibaba configuration issues**: Check if spring.ai.alibaba settings in application.yml are correct.

## Contribution & Feedback

Feel free to submit issues or pull requests.

---

> © 2024 Zhaoxi. For learning and communication only.
