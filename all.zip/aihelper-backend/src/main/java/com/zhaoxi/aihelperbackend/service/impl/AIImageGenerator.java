package com.zhaoxi.aihelperbackend.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import com.alibaba.cloud.ai.dashscope.image.DashScopeImageOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Base64;

/**
 * AI图像生成服务
 * 基于Spring AI Alibaba的ImageClient生成图像
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AIImageGenerator {

    @Autowired
    private ImageModel imageModel;

    /**
     * 根据提示词生成图像
     *
     * @param prompt 提示词
     * @param size 图像尺寸，例如 "1024*1024"
     * @return 生成的图像URL
     * @throws Exception 调用失败时抛出异常
     */
    public String generateImage(String prompt, String size) throws Exception {
        log.info("开始生成AI图像，提示词: {}", prompt);
        
        try {
            // 解析尺寸参数
            String[] dimensions = size.split("\\*");
            int width = 1024;
            int height = 1024;
            
            if (dimensions.length == 2) {
                try {
                    width = Integer.parseInt(dimensions[0].trim());
                    height = Integer.parseInt(dimensions[1].trim());
                } catch (NumberFormatException e) {
                    log.warn("无法解析图像尺寸: {}, 使用默认尺寸 1024x1024", size);
                }
            }
            
            // 创建图像选项
            DashScopeImageOptions options = DashScopeImageOptions.builder()
                    .withModel("wanx-v1") // 使用万相图像生成模型
                    .withWidth(width)
                    .withHeight(height)
                    .withN(1) // 生成1张图片
                    .build();
            
            // 创建图像提示
            ImagePrompt imagePrompt = new ImagePrompt(prompt, options);
            
            // 调用图像生成API
            log.info("调用Spring AI Alibaba图像生成API");
            ImageResponse response = imageModel.call(imagePrompt);
            
            if (response == null || response.getResults() == null || response.getResults().isEmpty()) {
                log.error("图像生成失败，返回结果为空");
                throw new Exception("图像生成失败，返回结果为空");
            }
            
            // 获取生成的图像URL
            String imageUrl = response.getResults().get(0).getOutput().getUrl();
            
            if (imageUrl == null || imageUrl.isEmpty()) {
                log.error("无法从响应中提取图像URL");
                throw new Exception("无法获取图像URL");
            }
            
            log.info("图像生成成功: {}", imageUrl);
            return imageUrl;
            
        } catch (Exception e) {
            log.error("图像生成过程中发生错误: {}", e.getMessage(), e);
            throw new Exception("图像生成失败: " + e.getMessage());
        }
    }
    
    /**
     * 从生成的图像URL下载图像数据
     *
     * @param imageUrl 图像URL
     * @return 图像字节数组
     * @throws Exception 下载失败时抛出异常
     */
    public byte[] downloadImage(String imageUrl) throws Exception {
        log.info("开始下载图像: {}", imageUrl);
        
        URL url = new URL(imageUrl);
        URLConnection connection = url.openConnection();
        
        try (InputStream inputStream = connection.getInputStream();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            
            byte[] buffer = new byte[4096];
            int bytesRead;
            
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            
            byte[] imageBytes = outputStream.toByteArray();
            log.info("图像下载成功，大小: {} 字节", imageBytes.length);
            
            return imageBytes;
        }
    }
    
    /**
     * 获取图像的Base64编码
     *
     * @param imageBytes 图像字节数组
     * @return Base64编码字符串
     */
    public String getBase64Image(byte[] imageBytes) {
        return Base64.getEncoder().encodeToString(imageBytes);
    }
}