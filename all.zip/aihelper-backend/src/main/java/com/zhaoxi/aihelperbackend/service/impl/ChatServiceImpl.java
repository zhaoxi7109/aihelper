package com.zhaoxi.aihelperbackend.service.impl;

import com.zhaoxi.aihelperbackend.dto.ChatRequest;
import com.zhaoxi.aihelperbackend.dto.ChatResponse;
import com.zhaoxi.aihelperbackend.dto.MessageImageResponse;
import com.zhaoxi.aihelperbackend.entity.Conversation;
import com.zhaoxi.aihelperbackend.entity.MessageImage;
import com.zhaoxi.aihelperbackend.service.ChatService;
import com.zhaoxi.aihelperbackend.service.ConversationService;
import com.zhaoxi.aihelperbackend.service.MessageImageService;
import com.zhaoxi.aihelperbackend.service.MessageService;
import com.zhaoxi.aihelperbackend.service.ChatRequestTracker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 聊天服务实现类
 * 使用Spring AI Alibaba框架提供AI聊天功能
 */
@Service
@Slf4j
public class ChatServiceImpl implements ChatService {

    @Autowired
    private ChatClient chatClient;
    
    @Autowired
    private ConversationService conversationService;
    
    @Autowired
    private MessageService messageService;
    
    @Autowired
    private MessageImageService messageImageService;

    @Autowired
    private ChatRequestTracker chatRequestTracker;

    /**
     * 处理聊天请求
     * 
     * @param request 聊天请求对象
     * @return 聊天响应对象
     */
    @Override
    @Transactional
    public ChatResponse chat(ChatRequest request) {
        try {
            if (request.getConversationId() != null) {
                chatRequestTracker.registerRequest(request.getConversationId());
            }
            
            // 处理会话
            Conversation conversation;
            List<com.zhaoxi.aihelperbackend.entity.Message> messageHistory = new ArrayList<>();
            
            if (request.getConversationId() != null) {
                // 使用现有会话
                conversation = conversationService.getConversationById(request.getConversationId());
                if (conversation == null) {
                    throw new RuntimeException("会话不存在");
                }
                // 获取历史消息
                messageHistory = messageService.getMessagesByConversationId(conversation.getId());
            } else {
                // 获取用户ID，如果请求中没有提供，则从安全上下文中获取
                Long userId = request.getUserId();
                if (userId == null) {
                    // 从当前认证信息中获取用户ID
                    org.springframework.security.core.Authentication authentication = 
                        org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
                    if (authentication != null && authentication.getPrincipal() instanceof com.zhaoxi.aihelperbackend.entity.User) {
                        com.zhaoxi.aihelperbackend.entity.User currentUser = 
                            (com.zhaoxi.aihelperbackend.entity.User) authentication.getPrincipal();
                        userId = currentUser.getId();
                    }
                    
                    if (userId == null) {
                        throw new RuntimeException("无法确定用户ID，请提供有效的用户ID或确保用户已登录");
                    }
                }
                
                // 创建新会话，使用请求中的model或默认model
                String modelName = request.getModel() != null ? request.getModel() : "qwen-plus";
                conversation = conversationService.createConversation(userId);
                conversation.setModel(modelName);
                conversationService.updateConversation(conversation);
            }
            
            // 保存用户消息
            com.zhaoxi.aihelperbackend.entity.Message userMessage = new com.zhaoxi.aihelperbackend.entity.Message();
            userMessage.setConversationId(conversation.getId());
            userMessage.setRole("user");
            userMessage.setContent(request.getPrompt());
            userMessage.setOrder(messageHistory.size());
            userMessage.setCreatedAt(LocalDateTime.now());
            userMessage.setUpdatedAt(LocalDateTime.now());
            
            // 判断是否有图片
            boolean hasImages = !CollectionUtils.isEmpty(request.getImageBase64List());
            if (hasImages) {
                userMessage.setHasImages(true);
            }
            
            // 保存消息，获取消息ID
            messageService.saveMessage(userMessage);
            
            // 处理用户消息中的图片并获取OCR文本
            StringBuilder ocrTextBuilder = new StringBuilder();
            List<MessageImage> processedImages = new ArrayList<>();
            
            if (hasImages) {
                Long userId = request.getUserId();
                if (userId == null) {
                    // 从当前认证信息中获取用户ID
                    org.springframework.security.core.Authentication authentication = 
                        org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
                    if (authentication != null && authentication.getPrincipal() instanceof com.zhaoxi.aihelperbackend.entity.User) {
                        com.zhaoxi.aihelperbackend.entity.User currentUser = 
                            (com.zhaoxi.aihelperbackend.entity.User) authentication.getPrincipal();
                        userId = currentUser.getId();
                    }
                }
                
                for (String base64Image : request.getImageBase64List()) {
                    try {
                        // 处理Base64图片
                        MessageImage image = messageImageService.createFromBase64(
                                base64Image, 
                                userMessage.getId(), 
                                userId, 
                                conversation.getId()
                        );
                        
                        processedImages.add(image);
                        
                        // 收集OCR文本
                        if (image.getOcrText() != null && !image.getOcrText().isEmpty()) {
                            if (ocrTextBuilder.length() > 0) {
                                ocrTextBuilder.append("\n\n");
                            }
                            ocrTextBuilder.append("图片文本: ").append(image.getOcrText());
                        }
                    } catch (Exception e) {
                        log.error("处理图片失败: {}", e.getMessage());
                        // 继续处理其他图片
                    }
                }
                
                // 设置图片到消息
                userMessage.setImages(processedImages);
            }
            
            // 准备消息历史
            List<Message> messages = convertToSpringAiMessages(messageHistory);
            
            // 组合图片OCR文本和用户输入文本作为完整的用户消息
            String userPrompt = request.getPrompt();
            if (!ocrTextBuilder.isEmpty()) {
                userPrompt += "\n\n" + ocrTextBuilder.toString();
            }
            
            // 添加当前用户消息
            messages.add(new UserMessage(userPrompt));
            
            // 检查是否应该停止生成
            if (request.getConversationId() != null && chatRequestTracker.shouldStop(request.getConversationId())) {
                // 生成已被用户中断
                chatRequestTracker.completeRequest(request.getConversationId());
                
                // 创建中断响应
                return new ChatResponse(conversation.getId(), "生成已被用户中断", null);
            }
            
            // 使用Spring AI Alibaba ChatClient调用AI模型
            org.springframework.ai.chat.model.ChatResponse aiResponse;
            
            if (request.getDeepThinking() != null && request.getDeepThinking()) {
                // 如果需要深度思考，使用特殊的提示词
                aiResponse = chatClient.prompt()
                    .messages(messages)
                    .call()
                    .chatResponse();
            } else {
                // 普通聊天
                aiResponse = chatClient.prompt()
                    .messages(messages)
                    .call()
                    .chatResponse();
            }
            
            // 提取AI响应内容
            String aiResponseContent = aiResponse.getResult().getOutput().getText();
            String reasoningContent = null;
            
            // 如果是深度思考模式，尝试提取推理内容（如果模型支持）
            if (request.getDeepThinking() != null && request.getDeepThinking()) {
                // 注意：这里需要根据实际模型的响应格式来提取推理内容
                // 目前先设置为null，后续可以根据具体模型的响应格式进行调整
                reasoningContent = null;
            }

            // 保存AI回复
            com.zhaoxi.aihelperbackend.entity.Message aiMessage = new com.zhaoxi.aihelperbackend.entity.Message();
            aiMessage.setConversationId(conversation.getId());
            aiMessage.setRole("assistant");
            aiMessage.setContent(aiResponseContent);
            aiMessage.setReasoningContent(reasoningContent);
            aiMessage.setOrder(messageHistory.size() + 1);
            aiMessage.setCreatedAt(LocalDateTime.now());
            aiMessage.setUpdatedAt(LocalDateTime.now());
            messageService.saveMessage(aiMessage);
            
            // 更新会话最后更新时间
            conversation.setUpdatedAt(LocalDateTime.now());
            conversationService.updateConversation(conversation);
            
            // 自动生成并更新会话标题（仅当是新会话或第一条消息时）
            if (messageHistory.isEmpty() || messageHistory.size() <= 1) {
                conversationService.generateAndUpdateTitle(conversation.getId());
            }
            
            // 构造响应对象，包含图片信息
            ChatResponse response = new ChatResponse(conversation.getId(), aiResponseContent, reasoningContent);
            
            // 如果用户消息有图片，将图片信息转换为响应DTO
            if (hasImages && !processedImages.isEmpty()) {
                try {
                    List<MessageImageResponse> imageResponses = processedImages.stream()
                            .map(image -> {
                                try {
                                    return messageImageService.toResponseDto(image);
                                } catch (Exception e) {
                                    log.error("转换图片DTO失败: {}", e.getMessage());
                                    return null;
                                }
                            })
                            .filter(Objects::nonNull)
                            .collect(Collectors.toList());
                    
                    response.setImages(imageResponses);
                } catch (Exception e) {
                    log.error("处理图片响应失败: {}", e.getMessage());
                }
            }
            
            if (request.getConversationId() != null) {
                chatRequestTracker.completeRequest(request.getConversationId());
            }
            
            return response;
            
        } catch (Exception e) {
            log.error("处理聊天请求失败: {}", e.getMessage(), e);
            throw new RuntimeException("处理聊天请求失败: " + e.getMessage(), e);
        }
    }
    
    /**
     * 将数据库中的消息转换为Spring AI消息格式
     * 
     * @param messageHistory 数据库消息历史
     * @return Spring AI消息列表
     */
    private List<Message> convertToSpringAiMessages(List<com.zhaoxi.aihelperbackend.entity.Message> messageHistory) {
        List<Message> messages = new ArrayList<>();
        
        for (com.zhaoxi.aihelperbackend.entity.Message dbMessage : messageHistory) {
            if ("user".equals(dbMessage.getRole())) {
                messages.add(new UserMessage(dbMessage.getContent()));
            } else if ("assistant".equals(dbMessage.getRole())) {
                messages.add(new AssistantMessage(dbMessage.getContent()));
            }
            // 系统消息可以根据需要添加
        }
        
        return messages;
    }

    /**
     * 停止指定会话的生成过程
     * 
     * @param conversationId 会话ID
     * @return 是否成功停止
     */
    @Override
    public boolean stopGeneration(Long conversationId) {
        if (conversationId == null) {
            return false;
        }
        return chatRequestTracker.requestStop(conversationId);
    }
}