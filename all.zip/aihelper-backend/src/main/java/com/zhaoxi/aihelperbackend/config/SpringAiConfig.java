package com.zhaoxi.aihelperbackend.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring AI Alibaba 配置类
 */
@Configuration
public class SpringAiConfig {

    /**
     * 配置ChatClient Bean
     * 
     * @param builder ChatClient.Builder
     * @return ChatClient实例
     */
    @Bean
    public ChatClient chatClient(ChatClient.Builder builder) {
        return builder
                .defaultSystem("你是一个智能助手，请用中文回答用户的问题。")
                .build();
    }
    
    /**
     * ImageModel Bean会由Spring AI Alibaba自动配置
     * 通过spring-ai-alibaba-starter-dashscope自动配置DashScopeImageModel
     * 无需手动配置，可直接通过@Autowired注入使用
     */
    // ImageModel会通过spring-ai-alibaba-starter-dashscope自动配置
}