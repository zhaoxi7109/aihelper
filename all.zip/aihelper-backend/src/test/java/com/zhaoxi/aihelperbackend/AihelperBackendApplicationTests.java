package com.zhaoxi.aihelperbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test") // 使用测试配置
class AihelperBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}

